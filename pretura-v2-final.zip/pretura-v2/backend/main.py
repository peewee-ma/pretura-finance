"""
PRETURA Finance API · v2
FastAPI + SQLite + Claude API
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import httpx, os, json, sqlite3
from datetime import datetime, date
from database import get_db, init_db, seed_2025

app = FastAPI(title="PRETURA Finance API v2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── Startup ──────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    init_db()
    # Seed nur wenn DB leer
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM buchungen")
    count = cur.fetchone()[0]
    conn.close()
    if count == 0:
        seed_2025()
        print("✓ Datenbank mit 2025-Daten initialisiert")

# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "service": "PRETURA Finance API v2"}

# ── DASHBOARD: Zusammenfassung ────────────────────────────────────────────────
@app.get("/api/dashboard")
async def dashboard(jahr: int = 2025):
    conn = get_db()
    cur = conn.cursor()

    # Einnahmen/Ausgaben nach Monat
    cur.execute("""
        SELECT strftime('%m', datum) as monat,
               SUM(CASE WHEN betrag > 0 THEN betrag ELSE 0 END) as einnahmen,
               SUM(CASE WHEN betrag < 0 THEN betrag ELSE 0 END) as ausgaben
        FROM buchungen
        WHERE konto = 'DB' AND strftime('%Y', datum) = ?
        GROUP BY monat ORDER BY monat
    """, (str(jahr),))
    monate = [dict(r) for r in cur.fetchall()]

    # KPIs
    cur.execute("""
        SELECT
            SUM(CASE WHEN betrag > 0 THEN betrag ELSE 0 END) as einnahmen,
            SUM(CASE WHEN betrag < 0 THEN betrag ELSE 0 END) as ausgaben
        FROM buchungen WHERE konto = 'DB' AND strftime('%Y', datum) = ?
    """, (str(jahr),))
    kpis = dict(cur.fetchone())

    # Realisierter G/V Investments
    cur.execute("""
        SELECT depot, SUM(gv_realisiert) as gv
        FROM investments
        WHERE strftime('%Y', datum) = ? AND typ IN ('Kauf','Verkauf')
        GROUP BY depot
    """, (str(jahr),))
    gv_by_depot = {r['depot']: r['gv'] for r in cur.fetchall()}

    # Dividenden
    cur.execute("""
        SELECT depot, SUM(endbetrag) as netto
        FROM investments
        WHERE strftime('%Y', datum) = ? AND typ IN ('Dividende','Ausschüttung')
        GROUP BY depot
    """, (str(jahr),))
    div_by_depot = {r['depot']: r['netto'] for r in cur.fetchall()}

    # Konto-Salden
    cur.execute("""
        SELECT konto, saldo FROM konto_salden
        WHERE strftime('%Y', stichtag) = ? AND stichtag = (
            SELECT MAX(stichtag) FROM konto_salden k2
            WHERE k2.konto = konto_salden.konto AND strftime('%Y', k2.stichtag) = ?
        )
    """, (str(jahr), str(jahr)))
    salden = {r['konto']: r['saldo'] for r in cur.fetchall()}

    conn.close()
    return {
        "monate": monate,
        "kpis": {
            "einnahmen": kpis.get("einnahmen", 0) or 0,
            "ausgaben": kpis.get("ausgaben", 0) or 0,
            "cashflow": (kpis.get("einnahmen", 0) or 0) + (kpis.get("ausgaben", 0) or 0),
        },
        "gv_by_depot": gv_by_depot,
        "div_by_depot": div_by_depot,
        "salden": salden,
        "jahr": jahr
    }

# ── BUCHUNGEN ─────────────────────────────────────────────────────────────────
@app.get("/api/buchungen")
async def buchungen(
    jahr: int = 2025,
    konto: str = None,
    kategorie: str = None,
    typ: str = None,    # einnahme | ausgabe
    limit: int = 200
):
    conn = get_db()
    cur = conn.cursor()
    q = "SELECT * FROM buchungen WHERE strftime('%Y', datum) = ?"
    params = [str(jahr)]
    if konto:
        q += " AND konto = ?"
        params.append(konto)
    if kategorie:
        q += " AND kategorie = ?"
        params.append(kategorie)
    if typ == "einnahme":
        q += " AND betrag > 0"
    elif typ == "ausgabe":
        q += " AND betrag < 0"
    q += " ORDER BY datum DESC LIMIT ?"
    params.append(limit)
    cur.execute(q, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"buchungen": rows, "count": len(rows)}

# ── KATEGORIEN-SUMMARY ────────────────────────────────────────────────────────
@app.get("/api/kategorien")
async def kategorien(jahr: int = 2025, konto: str = "DB"):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT kategorie,
               SUM(CASE WHEN betrag > 0 THEN betrag ELSE 0 END) as einnahmen,
               SUM(CASE WHEN betrag < 0 THEN betrag ELSE 0 END) as ausgaben,
               COUNT(*) as anzahl
        FROM buchungen
        WHERE strftime('%Y', datum) = ? AND konto = ?
        GROUP BY kategorie ORDER BY ABS(SUM(betrag)) DESC
    """, (str(jahr), konto))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"kategorien": rows}

# ── INVESTMENTS ───────────────────────────────────────────────────────────────
@app.get("/api/investments")
async def investments(
    jahr: int = 2025,
    depot: str = None,
    typ: str = None
):
    conn = get_db()
    cur = conn.cursor()
    q = "SELECT * FROM investments WHERE strftime('%Y', datum) = ?"
    params = [str(jahr)]
    if depot:
        q += " AND depot = ?"
        params.append(depot)
    if typ:
        q += " AND typ = ?"
        params.append(typ)
    q += " ORDER BY datum DESC"
    cur.execute(q, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"investments": rows, "count": len(rows)}

# ── DEPOT-POSITIONEN ──────────────────────────────────────────────────────────
@app.get("/api/depot")
async def depot(stichtag: str = "2025-12-31", depot: str = None):
    conn = get_db()
    cur = conn.cursor()
    q = "SELECT * FROM depot_positionen WHERE stichtag = ?"
    params = [stichtag]
    if depot:
        q += " AND depot = ?"
        params.append(depot)
    cur.execute(q, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"positionen": rows, "gesamt": sum(r['marktwert'] for r in rows)}

# ── KONTO-SALDEN ─────────────────────────────────────────────────────────────
@app.get("/api/salden")
async def salden(konto: str = None):
    conn = get_db()
    cur = conn.cursor()
    if konto:
        cur.execute("SELECT * FROM konto_salden WHERE konto = ? ORDER BY stichtag", (konto,))
    else:
        cur.execute("SELECT * FROM konto_salden ORDER BY konto, stichtag")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"salden": rows}

# ── UPLOAD + KI-VERARBEITUNG ─────────────────────────────────────────────────
@app.post("/api/upload")
async def upload(
    file: UploadFile = File(...),
    typ: str = Form(...),   # kontoauszug | depotauszug | btc_csv | wertpapiere
    konto: str = Form("DB")
):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="API Key nicht konfiguriert")

    content = await file.read()

    # Datei-Inhalt vorbereiten (Text-Extraktion)
    if file.filename.endswith('.json'):
        try:
            text_content = content.decode('utf-8')
        except:
            raise HTTPException(status_code=400, detail="JSON-Datei konnte nicht gelesen werden")
    elif file.filename.endswith('.csv'):
        text_content = content.decode('utf-8', errors='ignore')
    else:
        # PDF → Text (pdfplumber oder direkt als base64 an Claude)
        try:
            import pdfplumber, io
            with pdfplumber.open(io.BytesIO(content)) as pdf:
                text_content = "\n".join(page.extract_text() or "" for page in pdf.pages)
        except:
            text_content = content.decode('utf-8', errors='ignore')

    # Claude extrahiert die Buchungen
    system_prompt = """Du bist ein Finanz-Daten-Extraktor für PRETURA GmbH.
Extrahiere alle Buchungen/Transaktionen aus dem Dokument und gib sie als JSON zurück.

Format für Kontoauszug (konto=DB|flatex):
{"buchungen": [{"datum": "YYYY-MM-DD", "text": "...", "betrag": 1234.56, "kategorie": "..."}]}

Format für Investments (depot=flatex|IBKR|BTC):
{"investments": [{"datum": "YYYY-MM-DD", "typ": "Kauf|Verkauf|Dividende", "bezeichnung": "...", "isin": "...", "stueck": 100, "kurs": 5.50, "endbetrag": -550.00, "gv_realisiert": 0, "waehrung": "EUR"}]}

Kategorien für DB-Buchungen:
- Einnahmen: Provision Verkauf | Provision Vermietung | Honorare | WEG-Verwaltung | Sonstige Einnahmen
- Ausgaben: Personalkosten | Steuern | Büromiete | Marketing | Büro & IT | Fahrzeugkosten | Beratung | Sonstige Kosten | Depot-Einzahlung

Antworte NUR mit dem JSON-Objekt, kein Text darum."""

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 4000,
                "system": system_prompt,
                "messages": [{"role": "user", "content": f"Dokument-Typ: {typ}\nKonto: {konto}\n\n{text_content[:12000]}"}]
            }
        )

    if resp.status_code != 200:
        raise HTTPException(status_code=500, detail="Claude API Fehler")

    ai_text = resp.json()["content"][0]["text"].strip()

    # JSON parsen
    try:
        # Backticks entfernen falls vorhanden
        ai_text = ai_text.replace("```json","").replace("```","").strip()
        extracted = json.loads(ai_text)
    except:
        raise HTTPException(status_code=422, detail=f"KI konnte Daten nicht extrahieren: {ai_text[:200]}")

    # In DB speichern
    conn = get_db()
    cur = conn.cursor()
    saved = 0

    if "buchungen" in extracted:
        for b in extracted["buchungen"]:
            try:
                cur.execute("""
                    INSERT INTO buchungen (datum, text, betrag, konto, kategorie, quelle)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (b["datum"], b["text"], b["betrag"], konto, b.get("kategorie","Sonstige"), file.filename))
                saved += 1
            except Exception as e:
                print(f"Fehler bei Buchung: {e}")

    if "investments" in extracted:
        for inv in extracted["investments"]:
            try:
                cur.execute("""
                    INSERT INTO investments
                    (datum,depot,typ,isin,bezeichnung,stueck,kurs,kurswert,endbetrag,gv_realisiert,waehrung,quelle)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    inv["datum"], konto, inv["typ"],
                    inv.get("isin"), inv["bezeichnung"],
                    inv.get("stueck"), inv.get("kurs"),
                    inv.get("kurswert", inv.get("stueck",0) * inv.get("kurs",0) if inv.get("stueck") and inv.get("kurs") else 0),
                    inv["endbetrag"], inv.get("gv_realisiert",0),
                    inv.get("waehrung","EUR"), file.filename
                ))
                saved += 1
            except Exception as e:
                print(f"Fehler bei Investment: {e}")

    # Upload-Log
    cur.execute("""
        INSERT INTO uploads (dateiname, typ, konto, buchungen_count)
        VALUES (?, ?, ?, ?)
    """, (file.filename, typ, konto, saved))

    conn.commit()
    conn.close()

    return {"success": True, "datei": file.filename, "gespeichert": saved, "typ": typ}

# ── KI-CHAT ───────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    history: list = []
    kontext: dict = {}  # Optional: aktuelle Dashboard-Daten mitschicken

@app.post("/api/chat")
async def chat(req: ChatRequest):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="API Key nicht konfiguriert")

    # Live-Daten aus DB holen für Kontext
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT SUM(CASE WHEN betrag>0 THEN betrag ELSE 0 END) as ein, SUM(CASE WHEN betrag<0 THEN betrag ELSE 0 END) as aus FROM buchungen WHERE konto='DB' AND strftime('%Y',datum)='2025'")
    db_kpis = dict(cur.fetchone())

    cur.execute("SELECT SUM(gv_realisiert) as gv FROM investments WHERE strftime('%Y',datum)='2025' AND typ IN ('Kauf','Verkauf')")
    gv = cur.fetchone()[0] or 0

    cur.execute("SELECT SUM(endbetrag) as div FROM investments WHERE strftime('%Y',datum)='2025' AND typ IN ('Dividende','Ausschüttung')")
    div = cur.fetchone()[0] or 0

    cur.execute("SELECT COUNT(*) as cnt FROM buchungen WHERE konto='DB'")
    buch_count = cur.fetchone()[0]

    conn.close()

    kontext = f"""Du bist der PRETURA Finance Assistent (GJ 2025).
Aktuelle Daten aus der Datenbank:
- DB Einnahmen 2025: {db_kpis.get('ein', 0):,.2f} EUR
- DB Ausgaben 2025: {db_kpis.get('aus', 0):,.2f} EUR
- Cashflow 2025: {(db_kpis.get('ein',0) or 0) + (db_kpis.get('aus',0) or 0):,.2f} EUR
- Realisierter G/V Investments: {gv:,.2f} EUR
- Dividenden netto: {div:,.2f} EUR
- Buchungen in DB: {buch_count}
- flatex Saldo 31.12.2025: 28.050,30 EUR
- IBKR NAV 31.12.2025: 21.466,68 EUR
- Bitcoin Bestand 31.12.2025: 1,00024 BTC (Einstand 86.978 EUR)

Antworte auf Deutsch, präzise und mit konkreten Zahlen."""

    messages = [{"role": h["role"], "content": h["content"]} for h in req.history[-8:]]
    messages.append({"role": "user", "content": req.message})

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            },
            json={
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1200,
                "system": kontext,
                "messages": messages
            }
        )

    if resp.status_code != 200:
        raise HTTPException(status_code=resp.status_code, detail="API Fehler")

    return {"reply": resp.json()["content"][0]["text"]}

# ── KI-ANALYSE ────────────────────────────────────────────────────────────────
@app.post("/api/analyse")
async def analyse(typ: str = "monatsbericht", monat: str = None, jahr: int = 2025):
    """KI generiert automatisch einen Finanzbericht"""
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="API Key nicht konfiguriert")

    conn = get_db()
    cur = conn.cursor()

    if monat:
        cur.execute("""
            SELECT kategorie, SUM(betrag) as summe, COUNT(*) as anzahl
            FROM buchungen WHERE konto='DB' AND strftime('%Y-%m', datum) = ?
            GROUP BY kategorie ORDER BY ABS(SUM(betrag)) DESC
        """, (monat,))
    else:
        cur.execute("""
            SELECT strftime('%m', datum) as m, kategorie, SUM(betrag) as summe
            FROM buchungen WHERE konto='DB' AND strftime('%Y', datum) = ?
            GROUP BY m, kategorie ORDER BY m, ABS(SUM(betrag)) DESC
        """, (str(jahr),))

    daten = [dict(r) for r in cur.fetchall()]
    conn.close()

    prompt_map = {
        "monatsbericht": f"Erstelle einen kurzen Monatsbericht (5-8 Sätze) für {monat or str(jahr)} basierend auf diesen Buchungsdaten:\n{json.dumps(daten, ensure_ascii=False, indent=2)}",
        "anomalien": f"Analysiere diese Buchungsdaten auf Anomalien, ungewöhnliche Ausgaben oder auffällige Muster:\n{json.dumps(daten, ensure_ascii=False, indent=2)}",
        "empfehlungen": f"Gib 3-5 konkrete Handlungsempfehlungen basierend auf diesen Finanzdaten:\n{json.dumps(daten, ensure_ascii=False, indent=2)}",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": "claude-sonnet-4-20250514", "max_tokens": 800,
                  "system": "Du bist Finanzanalyst für PRETURA GmbH. Antworte auf Deutsch, professionell und präzise.",
                  "messages": [{"role": "user", "content": prompt_map.get(typ, prompt_map["monatsbericht"])}]}
        )

    return {"analyse": resp.json()["content"][0]["text"], "typ": typ}


# ── GOOGLE SHEETS PROXY ───────────────────────────────────────
@app.get("/api/sheets")
async def sheets_proxy(sheet_id: str, gid: int = 0):
    """Lädt CSV-Daten aus Google Sheets serverseitig (umgeht Browser CORS/Mixed-Content)"""
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0"})
    if resp.status_code != 200:
        raise HTTPException(status_code=resp.status_code, detail="Sheet nicht erreichbar. Ist es öffentlich freigegeben?")
    return {"csv": resp.text, "rows": len(resp.text.strip().split("\n"))-1}

# ── UPLOADS LISTE ─────────────────────────────────────────────────────────────
@app.get("/api/uploads")
async def uploads_liste():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM uploads ORDER BY erstellt_am DESC LIMIT 50")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"uploads": rows}

# ── FRONTEND SERVING ──────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return FileResponse("/frontend/index.html")
