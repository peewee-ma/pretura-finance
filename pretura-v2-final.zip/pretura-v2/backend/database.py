"""
PRETURA Finance · Datenbank-Schema & Seed
SQLite via SQLAlchemy
"""

import sqlite3
import os
from datetime import date

DB_PATH = os.environ.get("DB_PATH", "/data/pretura.db")

# ── Schema ───────────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS buchungen (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    datum       DATE NOT NULL,
    text        TEXT NOT NULL,
    betrag      REAL NOT NULL,
    konto       TEXT NOT NULL,          -- DB | flatex | IBKR | BTC | Coinfinity
    kategorie   TEXT NOT NULL,
    unterkategorie TEXT,
    quelle      TEXT,                   -- Dateiname der Quelle
    erstellt_am DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS investments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    datum       DATE NOT NULL,
    depot       TEXT NOT NULL,          -- flatex | IBKR | BTC
    typ         TEXT NOT NULL,          -- Kauf | Verkauf | Dividende | Ausschüttung
    isin        TEXT,
    bezeichnung TEXT NOT NULL,
    stueck      REAL,
    kurs        REAL,
    kurswert    REAL,
    provision   REAL DEFAULT 0,
    gv_realisiert REAL DEFAULT 0,
    steuer      REAL DEFAULT 0,
    endbetrag   REAL NOT NULL,
    waehrung    TEXT DEFAULT 'EUR',
    handelsplatz TEXT,
    quelle      TEXT,
    erstellt_am DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS depot_positionen (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    stichtag    DATE NOT NULL,
    depot       TEXT NOT NULL,
    isin        TEXT,
    bezeichnung TEXT NOT NULL,
    stueck      REAL,
    kurs        REAL,
    marktwert   REAL NOT NULL,
    waehrung    TEXT DEFAULT 'EUR',
    erstellt_am DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS konto_salden (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    stichtag    DATE NOT NULL,
    konto       TEXT NOT NULL,
    saldo       REAL NOT NULL,
    erstellt_am DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(stichtag, konto)
);

CREATE TABLE IF NOT EXISTS uploads (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    dateiname   TEXT NOT NULL,
    typ         TEXT NOT NULL,          -- kontoauszug | depotauszug | wertpapiere | btc
    konto       TEXT,
    zeitraum_von DATE,
    zeitraum_bis DATE,
    buchungen_count INTEGER DEFAULT 0,
    status      TEXT DEFAULT 'verarbeitet',
    erstellt_am DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_buchungen_datum ON buchungen(datum);
CREATE INDEX IF NOT EXISTS idx_buchungen_konto ON buchungen(konto);
CREATE INDEX IF NOT EXISTS idx_investments_depot ON investments(depot);
CREATE INDEX IF NOT EXISTS idx_investments_datum ON investments(datum);
"""

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
    print(f"✓ Datenbank initialisiert: {DB_PATH}")

def seed_2025():
    """Alle bekannten 2025-Daten einspielen"""
    conn = get_db()
    cur = conn.cursor()

    # ── Deutsche Bank Buchungen 2025 ─────────────────────────────────────────
    db_buchungen = [
        # (datum, text, betrag, kategorie)
        # Januar
        ("2025-01-05","Maklercourtage Verkauf C-1845",14500,"Provision Verkauf"),
        ("2025-01-08","Gehaltszahlung Mitarbeiter Januar",-5800,"Personalkosten"),
        ("2025-01-10","ImmoScout24 Monatsgebühr",-820,"Marketing"),
        ("2025-01-15","Steuervorauszahlung Q1 2025",-7800,"Steuern"),
        ("2025-01-17","WEG-Verwaltungsgebühren Q4 2024",-1200,"WEG-Verwaltung"),
        ("2025-01-20","Provision Vermietung Objekt C-1840",3200,"Provision Vermietung"),
        ("2025-01-22","Büromiete Otto-Beck-Str. 4",-1950,"Büromiete"),
        ("2025-01-25","Kfz-Kosten Firmenwagen",-420,"Fahrzeugkosten"),
        # Februar
        ("2025-02-05","Maklercourtage Verkauf C-1846",18900,"Provision Verkauf"),
        ("2025-02-08","Gehaltszahlung Mitarbeiter Februar",-5800,"Personalkosten"),
        ("2025-02-12","Steuerberatungskosten",-1800,"Beratung"),
        ("2025-02-14","IT Software Adobe Cloud",-240,"Büro & IT"),
        ("2025-02-18","Notarkosten Objektkauf",-2400,"Sonstige Kosten"),
        ("2025-02-20","Provision Vermietung C-1841",2800,"Provision Vermietung"),
        ("2025-02-22","Büromiete Februar",-1950,"Büromiete"),
        # März
        ("2025-03-06","Maklercourtage Verkauf C-1848",22500,"Provision Verkauf"),
        ("2025-03-08","Gehaltszahlung Mitarbeiter März",-5800,"Personalkosten"),
        ("2025-03-12","Immowelt.de Monatsgebühr",-680,"Marketing"),
        ("2025-03-15","Steuervorauszahlung Q1 Abschluss",-7800,"Steuern"),
        ("2025-03-20","Honorar Gutachten Immobilienwert",3500,"Honorare"),
        ("2025-03-22","Büromiete März",-1950,"Büromiete"),
        # April
        ("2025-04-07","Maklercourtage Verkauf C-1847",19800,"Provision Verkauf"),
        ("2025-04-08","Gehaltszahlung Mitarbeiter April",-5800,"Personalkosten"),
        ("2025-04-10","Google Ads Kampagne",-1200,"Marketing"),
        ("2025-04-15","Jahresabschluss Steuerberater",-3200,"Beratung"),
        ("2025-04-18","ImmoScout Premium",-1640,"Marketing"),
        ("2025-04-22","Büromiete April",-1950,"Büromiete"),
        # Mai
        ("2025-05-06","Provision Vermietung C-1843",4200,"Provision Vermietung"),
        ("2025-05-08","Gehaltszahlung Mitarbeiter Mai",-5800,"Personalkosten"),
        ("2025-05-14","Körperschaftsteuer Vorauszahlung",-4600,"Steuern"),
        ("2025-05-16","Social Media Ads",-680,"Marketing"),
        ("2025-05-20","Honorar Beratung Investor",5500,"Honorare"),
        ("2025-05-22","Büromiete Mai",-1950,"Büromiete"),
        # Juni
        ("2025-06-05","Maklercourtage Verkauf C-1850",16200,"Provision Verkauf"),
        ("2025-06-08","Gehaltszahlung Mitarbeiter Juni",-5800,"Personalkosten"),
        ("2025-06-15","Steuervorauszahlung Q2 2025",-7800,"Steuern"),
        ("2025-06-18","Versicherung Betriebshaftpflicht",-1240,"Sonstige Kosten"),
        ("2025-06-22","Büromiete Juni",-1950,"Büromiete"),
        # Juli
        ("2025-07-07","Maklercourtage Verkauf C-1851",17600,"Provision Verkauf"),
        ("2025-07-08","Gehaltszahlung Mitarbeiter Juli",-5800,"Personalkosten"),
        ("2025-07-14","Rechtsanwalt Mietrecht",-1800,"Beratung"),
        ("2025-07-22","Büromiete Juli",-1950,"Büromiete"),
        ("2025-07-25","Honorar Wertermittlung Objekt",3800,"Honorare"),
        # August
        ("2025-08-06","Provision Vermietung C-1844",3600,"Provision Vermietung"),
        ("2025-08-08","Gehaltszahlung Mitarbeiter August",-5800,"Personalkosten"),
        ("2025-08-14","Steuervorauszahlung Q3",-7800,"Steuern"),
        ("2025-08-15","Büroausstattung Laptop",-1890,"Büro & IT"),
        ("2025-08-22","Büromiete August",-1950,"Büromiete"),
        # September
        ("2025-09-05","Maklercourtage Verkauf C-1853",21400,"Provision Verkauf"),
        ("2025-09-08","Gehaltszahlung Mitarbeiter September",-5800,"Personalkosten"),
        ("2025-09-12","ImmoScout24 Jahresvertrag",-2460,"Marketing"),
        ("2025-09-22","Büromiete September",-1950,"Büromiete"),
        ("2025-09-26","Honorar Sachverständigengutachten",4200,"Honorare"),
        # Oktober
        ("2025-10-07","Provision Vermietung C-1846",4800,"Provision Vermietung"),
        ("2025-10-08","Gehaltszahlung Mitarbeiter Oktober",-5800,"Personalkosten"),
        ("2025-10-14","Körperschaftsteuer Vorauszahlung Q4",-4600,"Steuern"),
        ("2025-10-18","Gewerbesteuer Vorauszahlung",-3200,"Steuern"),
        ("2025-10-22","Büromiete Oktober",-1950,"Büromiete"),
        # November
        ("2025-11-06","Maklercourtage Verkauf C-1855",14900,"Provision Verkauf"),
        ("2025-11-08","Gehaltszahlung Mitarbeiter November",-5800,"Personalkosten"),
        ("2025-11-14","Steuervorauszahlung Q4",-7800,"Steuern"),
        ("2025-11-20","Honorar Portfolioberatung",2800,"Honorare"),
        ("2025-11-22","Büromiete November",-1950,"Büromiete"),
        # Dezember
        ("2025-12-05","Maklercourtage Verkauf C-1857",18400,"Provision Verkauf"),
        ("2025-12-08","Gehaltszahlung Mitarbeiter Dezember",-5800,"Personalkosten"),
        ("2025-12-10","Jahres-Prüfung Steuerberater",-2800,"Beratung"),
        ("2025-12-15","Weihnachtsgratifikation",-2400,"Personalkosten"),
        ("2025-12-22","Büromiete Dezember",-1950,"Büromiete"),
        ("2025-12-30","Rückstellungen Jahresabschluss",-4200,"Sonstige Kosten"),
    ]

    cur.executemany("""
        INSERT OR IGNORE INTO buchungen (datum, text, betrag, konto, kategorie, quelle)
        VALUES (?, ?, ?, 'DB', ?, 'seed_2025')
    """, [(d,t,b,k) for d,t,b,k in db_buchungen])

    # ── flatex Depot-Einzahlungen ─────────────────────────────────────────────
    flatex_ez = [
        ("2025-05-01", "Überweisung Geldtransit Depot flatex Q2", -17500, "Depot-Einzahlung"),
        ("2025-08-12", "Überweisung Geldtransit Depot flatex Q3", -17500, "Depot-Einzahlung"),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO buchungen (datum, text, betrag, konto, kategorie, quelle)
        VALUES (?, ?, ?, 'flatex', ?, 'seed_2025')
    """, [(d,t,b,k) for d,t,b,k in flatex_ez])

    # ── Konto-Salden ──────────────────────────────────────────────────────────
    salden = [
        # flatex
        ("2024-07-31","flatex",15947.30),
        ("2024-09-30","flatex",15947.30),
        ("2024-12-31","flatex",36439.15),
        ("2025-03-31","flatex",57313.45),
        ("2025-06-30","flatex",15258.49),
        ("2025-09-30","flatex",33741.46),
        ("2025-12-31","flatex",28050.30),
        # IBKR
        ("2024-12-31","IBKR",34388.58),
        ("2025-12-31","IBKR",21466.68),
        # BTC Einstand
        ("2025-12-31","BTC",86978.36),
    ]
    cur.executemany("""
        INSERT OR REPLACE INTO konto_salden (stichtag, konto, saldo)
        VALUES (?, ?, ?)
    """, salden)

    # ── flatex Investments 2025 (Auszug wichtigste) ──────────────────────────
    fx_invest = [
        ("2025-01-20","flatex","Verkauf","DE000MJ4QR24","MS TURBOL MIGA MICROSTRATEGY",1500,13.64,20460,0,2985,0,20460,"EUR","Morgan Stanley"),
        ("2025-01-23","flatex","Verkauf","DE000ME4P5L6","MS TURBOL ALV ALLIANZ SE",2000,6.68,13360,0,1520,0,13360,"EUR","Morgan Stanley"),
        ("2025-01-27","flatex","Verkauf","DE000GQ8SG77","GS TUBULL M4I MAS",2000,10.87,21736.10,3.90,2580,0,21736.10,"EUR","Goldman Sachs"),
        ("2025-03-18","flatex","Verkauf","DE000MG0VRC3","MS TURBOL IOS IONOS",1500,4.75,7125,0,1125,0,7125,"EUR","Morgan Stanley"),
        ("2025-07-11","flatex","Verkauf","DE000VC1HCL6","VONT MINIL BTC",220,53.75,11821.10,3.90,2244.40,0,11821.10,"EUR","Vontobel"),
        ("2025-09-02","flatex","Verkauf","DE000FA1Q2N3","SG TURBOS DAX",12500,1.18,14748.10,1.90,2350,0,14748.10,"EUR","Société Générale"),
        ("2025-11-12","flatex","Verkauf","DE000VC3PTR6","VONT MINIL BTC",500,34.19,17091.10,3.90,-4020,0,17091.10,"EUR","Vontobel"),
        ("2025-10-01","flatex","Verkauf","DE000JU3RF70","JPM TURBOS DAX",1000,2.13,2130,0,-2830,0,2130,"EUR","J.P. Morgan"),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO investments
        (datum,depot,typ,isin,bezeichnung,stueck,kurs,kurswert,provision,gv_realisiert,steuer,endbetrag,waehrung,handelsplatz,quelle)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'seed_2025')
    """, fx_invest)

    # ── IBKR Dividenden 2025 ─────────────────────────────────────────────────
    ibkr_div = [
        ("2025-03-24","IBKR","Dividende","NL0015002E16","Shell PLC (Scrip)",None,None,33.48,0,0,0,33.48,"EUR",None),
        ("2025-05-07","IBKR","Dividende","DE000BASF111","BASF SE",100,2.25,225.00,0,0,59.34,165.66,"EUR",None),
        ("2025-05-12","IBKR","Dividende","DE0007100000","Mercedes-Benz Group AG",100,4.30,430.00,0,0,113.41,316.59,"EUR",None),
        ("2025-06-23","IBKR","Dividende","NL0015002HW4","Shell PLC (Scrip)",None,None,31.67,0,0,0,31.67,"EUR",None),
        ("2025-07-07","IBKR","Dividende","DE0006052830","Hermle AG Vorzug (MBH3)",100,11.05,1105.00,0,0,291.44,813.56,"EUR",None),
        ("2025-07-23","IBKR","Dividende","DE000A13SUL5","DEFAMA AG",50,0.60,30.00,0,0,7.91,22.09,"EUR",None),
        ("2025-09-22","IBKR","Dividende","NL0015002L33","Shell PLC (Scrip)",None,None,30.99,0,0,0,30.99,"EUR",None),
        ("2025-12-18","IBKR","Dividende","NL0015002SG4","Shell PLC (Scrip)",None,None,31.01,0,0,0,31.01,"EUR",None),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO investments
        (datum,depot,typ,isin,bezeichnung,stueck,kurs,kurswert,provision,gv_realisiert,steuer,endbetrag,waehrung,handelsplatz,quelle)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'seed_2025')
    """, ibkr_div)

    # ── BTC Käufe 2025 ────────────────────────────────────────────────────────
    btc_kaeufe = [
        ("2025-07-24","BTC","Kauf",None,"Bitcoin (BTC)",0.0048973,102097.07,500,0,0,0,-500,"EUR","Coinfinity"),
        ("2025-07-25","BTC","Kauf",None,"Bitcoin (BTC)",0.02519465,99227.42,2500,0,0,0,-2500,"EUR","Coinfinity"),
        ("2025-08-20","BTC","Kauf",None,"Bitcoin (BTC)",0.05075615,98510.23,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-08-25","BTC","Kauf",None,"Bitcoin (BTC)",0.05183087,96467.61,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-09-16","BTC","Kauf",None,"Bitcoin (BTC)",0.02529034,98851.97,2500,0,0,0,-2500,"EUR","Coinfinity"),
        ("2025-09-22","BTC","Kauf",None,"Bitcoin (BTC)",0.05145636,97169.72,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-09-26","BTC","Kauf",None,"Bitcoin (BTC)",0.03170618,94618.78,3000,0,0,0,-3000,"EUR","Coinfinity"),
        ("2025-10-13","BTC","Kauf",None,"Bitcoin (BTC)",0.01490715,100622.86,1500,0,0,0,-1500,"EUR","Coinfinity"),
        ("2025-10-17","BTC","Kauf",None,"Bitcoin (BTC)",0.03878204,90247.96,3500,0,0,0,-3500,"EUR","Coinfinity"),
        ("2025-10-31","BTC","Kauf",None,"Bitcoin (BTC)",0.05216792,95844.34,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-11-04","BTC","Kauf",None,"Bitcoin (BTC)",0.10962069,91223.65,10000,0,0,0,-10000,"EUR","Coinfinity"),
        ("2025-11-04","BTC","Kauf",None,"Bitcoin (BTC)",0.0548565,91146.90,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-11-12","BTC","Kauf",None,"Bitcoin (BTC)",0.0563133,88788.97,5000,0,0,0,-5000,"EUR","Coinfinity"),
        ("2025-11-14","BTC","Kauf",None,"Bitcoin (BTC)",0.0505583,84061.37,4250,0,0,0,-4250,"EUR","Coinfinity"),
        ("2025-11-20","BTC","Kauf",None,"Bitcoin (BTC)",0.08680271,80642.64,7000,0,0,0,-7000,"EUR","Coinfinity"),
        ("2025-12-01","BTC","Kauf",None,"Bitcoin (BTC)",0.20009989,74957.56,14999,0,0,0,-14999,"EUR","Coinfinity"),
        ("2025-12-02","BTC","Kauf",None,"Bitcoin (BTC)",0.095,76098.53,7229.36,0,0,0,-7229.36,"EUR","Coinfinity"),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO investments
        (datum,depot,typ,isin,bezeichnung,stueck,kurs,kurswert,provision,gv_realisiert,steuer,endbetrag,waehrung,handelsplatz,quelle)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'seed_2025')
    """, btc_kaeufe)

    # ── Depot-Positionen per 31.12.2024 (flatex) ─────────────────────────────
    depot_31_12_2024 = [
        ("2024-12-31","flatex","DE000JV12RZ8","JPM TURBOL PAYPAL HOLDING",10000,0.94,9400,"EUR"),
        ("2024-12-31","flatex","DE000ME4P5L6","MS TURBOL ALV ALLIANZ SE",2000,5.39,10780,"EUR"),
        ("2024-12-31","flatex","DE000MJ4QR24","MS TURBOL MIGA MICROSTRATEGY",1500,4.98,7470,"EUR"),
        ("2024-12-31","flatex","DE000MJ5V8P1","MS TURBOL AMZ AMAZON",5000,2.27,11350,"EUR"),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO depot_positionen
        (stichtag,depot,isin,bezeichnung,stueck,kurs,marktwert,waehrung)
        VALUES (?,?,?,?,?,?,?,?)
    """, depot_31_12_2024)

    # ── Depot-Positionen per 31.12.2025 (IBKR) ───────────────────────────────
    depot_ibkr_2025 = [
        ("2025-12-31","IBKR","DE000BASF111","BASF SE",100,44.43,4443,"EUR"),
        ("2025-12-31","IBKR","DE000A13SUL5","DEFAMA AG",50,27.80,1390,"EUR"),
        ("2025-12-31","IBKR","DE0007100000","Mercedes-Benz Group AG",100,60.07,6007,"EUR"),
        ("2025-12-31","IBKR","GB00BP6MXD84","Shell PLC",101,31.475,3178.98,"EUR"),
        ("2025-12-31","IBKR","US9497461015","Wells Fargo & Co.",50,93.20,3967,"USD"),
    ]
    cur.executemany("""
        INSERT OR IGNORE INTO depot_positionen
        (stichtag,depot,isin,bezeichnung,stueck,kurs,marktwert,waehrung)
        VALUES (?,?,?,?,?,?,?,?)
    """, depot_ibkr_2025)

    conn.commit()
    conn.close()

    # Statistik
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM buchungen")
    b = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM investments")
    i = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM depot_positionen")
    d = cur.fetchone()[0]
    conn.close()
    print(f"✓ Seed abgeschlossen: {b} Buchungen | {i} Investments | {d} Depot-Positionen")

if __name__ == "__main__":
    init_db()
    seed_2025()
